class Task {
	constructor(task, id) {
		this.task = task;
		this.id = id;		
	}

	printTask() {
		console.log("your task is: " + this.name);
	}

	DeleteTask() {
		this.task = " ";
	}
    AddTask(){

    }
}

